import os
ROOT_PATH = os.getcwd()
BUCKET_NAME = 'transcript_download'

VIDEO_EXTENSIONS = ['mp4', 'ogg', 'webm', 'avi', 'mov', 'mpg']
AUDIO_EXTENSIONS = ['mp3', 'MP3', 'm4a', 'wma', 'wav']